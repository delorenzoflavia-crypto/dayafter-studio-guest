# Day After Studio — Guest

Sorgente pronto per Render Static Sites.

Carica index.html e render.yaml nella radice di un repository GitHub.

Su Render: New > Static Site, seleziona il repository, branch main, Build Command: `echo "Build statico"`, Publish Directory: `.`.

Il progetto funziona in browser e salva nel localStorage dell’utente; non c’è backend né sincronizzazione tra utenti.
Non pubblicare documenti o dataset interni nell’HTML.
